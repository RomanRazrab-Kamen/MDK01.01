﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Character
{
    internal class Personage
    {
        private string name;
        private int lvl;
        private int speed;
        private int Dexterity;
        private int Intellect;
        private Weapon weapon;
        public Personage(string name = "Безымянный персонаж", int lvl = 1, int speed = 0, int Dexterity = 0, int Intellect = 0, Weapon weapon = null)
        {
            this.name = name;
            this.lvl = lvl;
            this.speed = speed;
            this.Dexterity = Dexterity;
            this.Intellect = Intellect;
            this.weapon = weapon;
        }

        public string Name { get { return name; } set { name = value; } }
        public int Lvl 
        { 
            get 
            { 
                return lvl; 
            } 
            set 
            { 
                if (value < 0)
                {

                    lvl = 0;
                    throw new ArgumentException("Уровень не может быть отрицательным!");
                }
                lvl = value; 
            } 
        }
        public int Speed
        {
            get
            {
                return speed;
            }
            set
            {
                if (value < 0)
                {
                    speed = 0;
                    throw new ArgumentException("Скорость не может быть отрицательной!");
                }
                speed = value;
            }
        }
        public int dexterity
        {
            get
            {
                return Dexterity;
            }
            set
            {
                if (value < 0)
                {
                    Dexterity = 0;
                    throw new ArgumentException("Ловкость не может быть отрицательной!");
                }
                Dexterity = value;
            }
        }
        public int intellect
        {
            get
            {
                return Intellect;
            }
            set
            {
                if (value < 0)
                {
                    Intellect = 0;
                    throw new ArgumentException("Интелект не может быть отрицательным!");
                }
                Intellect = value;
            }
        }
        public Weapon Weapon { get { return weapon; } set { weapon = value; } }

        public int GetPower(int lvl, int speed, int Dexterity, int Intellect, Weapon weapon)
        {
            
            decimal power = 0;
            power = ((speed + Dexterity + Intellect) * lvl) + weapon.Lvl + weapon.damage;
            if (power < 0)
            {
                throw new ArgumentException("Персонаж слишком силен!");
            }
            return Convert.ToInt32(power);
        }
        public string Title(int Power, string type_Weapon)
        {
            switch (type_Weapon) 
            {
                case "Меч":
                    if (Power <= 50) 
                        return "Просто мечник";
                    if (Power > 50 && Power <= 100 ) 
                        return "Хороший мечник";
                    if (Power > 100 && Power <= 200) 
                        return "Отличный мечник";
                    if (Power > 200 && Power <= 400) 
                        return "Великолепный мечник";
                    if (Power > 400) 
                        return "Безупречный мечник";
                    break;

                case "Клинки":
                    if (Power <= 50)
                        return "Кадет";
                    if (Power > 50 && Power <= 100)
                        return "Рядовой";
                    if (Power > 100 && Power <= 200)
                        return "Ефрейтор";
                    if (Power > 200 && Power <= 400)
                        return "Младший капрал";
                    if (Power > 400)
                        return "Капрал";
                    break;

                case "Щит":
                    if (Power <= 50)
                        return "Просто щитоносец";
                    if (Power > 50 && Power <= 100)
                        return "Хороший щитоносец";
                    if (Power > 100 && Power <= 200)
                        return "Отличный щитоносец";
                    if (Power > 200 && Power <= 400)
                        return "Великолепный щитоносец";
                    if (Power > 400)
                        return "Безупречный щитоносец";
                    break;

                case "Лук":
                    if (Power <= 50)
                        return "Просто лучник";
                    if (Power > 50 && Power <= 100)
                        return "Хороший лучник";
                    if (Power > 100 && Power <= 200)
                        return "Отличный лучник";
                    if (Power > 200 && Power <= 400)
                        return "Великолепный лучник";
                    if (Power > 400)
                        return "Безупречный лучник";
                    break;
            }
            throw new ArgumentException("Невозможно получить титул");
        }
    }
}
