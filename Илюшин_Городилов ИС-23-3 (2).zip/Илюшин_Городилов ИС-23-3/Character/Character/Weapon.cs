﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Automation.Peers;

namespace Character
{
    internal class Weapon
    {
        private string name;
        private int lvl;
        private int Damage;
        private string Type_Weapon;

        public Weapon(string name = "Безымянный ", int lvl = 1, int Damage = 10, string Type_weapon = "Щит")
        {
            this.name = name;
            this.Damage = Damage;
            this.lvl = lvl;
            this.Type_Weapon = Type_weapon;
        }

        public string Name
        {
            get { return name; }
            set { name = value;}
        }
        public int Lvl
        {
            get { return lvl; }
            set { lvl = value; }
        }

        public int damage
        {
            get { return Damage; }
            set { Damage = value; }
        }
        public string type_Weapon
        {
            get { return Type_Weapon; }
            set { Type_Weapon = value; }
        }
       
        public static Weapon operator +(Weapon i1, Weapon i2)
        {
            if(i1.type_Weapon == i2.type_Weapon)
            {
                string name = "";
                int Damage = 0;
                int lvl = 0;
                string Type_Weapon = "";

                Type_Weapon = i1.Type_Weapon;
                if (i1.lvl > i2.lvl)
                {
                    name = i1.name + "+";
                    lvl = i1.lvl + 1;
                    Damage = i1.Damage + i2.Damage;
                }
                if (i2.lvl > i1.lvl)
                {
                    name = i2.name + "+";
                    lvl = i2.lvl + 1;
                    Damage = i2.Damage + i1.Damage;
                }
                if (i1.lvl == i2.lvl)
                {
                    name = i1.name + "+";
                    lvl = i2.lvl + 1;
                    Damage = i2.Damage + i1.Damage;
                }
                return new Weapon(name, lvl, Damage, Type_Weapon);
            }
            throw new ArgumentException("Улучшение невозможно, типы оружия не совподают!");
        }
    }
}
