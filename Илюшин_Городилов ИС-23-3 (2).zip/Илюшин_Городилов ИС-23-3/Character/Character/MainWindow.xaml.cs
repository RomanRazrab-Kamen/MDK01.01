﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Character
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        List<Weapon> Weapons = new List<Weapon>();
        List<Personage> Characters = new List<Personage>();
        private void Button_AddWeapon(object sender, RoutedEventArgs e)
        {
            Weapon New_Weapon;
            try
            {
                string Name = Text_Name.Text;
                string Lvl = Text_Lvl.Text;
                string Damage = Text_Damage.Text;
                New_Weapon = new Weapon();
                if(Name != string.Empty)
                {
                    New_Weapon.Name = Name;
                }
                else
                {
                    MessageBox.Show("Имя заменено по умолчанию (Неверный формат)");
                }
                if (Lvl != string.Empty && int.TryParse(Lvl, out int reslvl))
                {
                    New_Weapon.Lvl = reslvl;
                }
                else
                {
                    MessageBox.Show("Уровень заменен по умолчанию (Неверный формат)");
                }
                if (Damage != string.Empty && int.TryParse(Damage, out int resdmg))
                {
                    New_Weapon.damage = resdmg;
                }
                else
                {
                    MessageBox.Show("Урон заменен по умолчанию (Неверный формат)");
                }
                if (Combo_TypeWeapon.SelectedIndex != -1)
                {
                    New_Weapon.type_Weapon = Combo_TypeWeapon.Text;
                }
                else
                {
                    MessageBox.Show("Тип заменен по умолчанию (Не выбран тип)");
                }
                Weapons.Add(New_Weapon);
            }
            catch
            {

            }
            ListWeapons.Items.Clear();
            Combo_First.Items.Clear();
            Combo_Second.Items.Clear();
            Personage_Weapon.Items.Clear();
            foreach (Weapon weapon in Weapons)
            {
                ListWeapons.Items.Add($"{weapon.type_Weapon}: {weapon.Name}, lvl {weapon.Lvl}, dm {weapon.damage}");
                Combo_First.Items.Add($"{weapon.type_Weapon}: {weapon.Name}, lvl {weapon.Lvl}, dm {weapon.damage}");
                Combo_Second.Items.Add($"{weapon.type_Weapon}: {weapon.Name}, lvl {weapon.Lvl}, dm {weapon.damage}");
                Personage_Weapon.Items.Add($"{weapon.type_Weapon}: {weapon.Name}, lvl {weapon.Lvl}, dm {weapon.damage}");
            }
        }

        private void Button_Upgrade_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(Combo_First.SelectedIndex != Combo_Second.SelectedIndex)
                {
                    var First_Weapon = Weapons[Combo_First.SelectedIndex];
                    var Second_Weapon = Weapons[Combo_Second.SelectedIndex];
                    var Up_Weapon = First_Weapon + Second_Weapon;

                    Weapons.Remove(First_Weapon);
                    Weapons.Remove(Second_Weapon);
                    Weapons.Add(Up_Weapon);

                    ListWeapons.Items.Clear();
                    Combo_First.Items.Clear();
                    Combo_Second.Items.Clear();
                    Personage_Weapon.Items.Clear();
                    foreach (Weapon weapon in Weapons)
                    {
                        ListWeapons.Items.Add($"{weapon.type_Weapon}: {weapon.Name}, lvl {weapon.Lvl}, dm {weapon.damage}");
                        Combo_First.Items.Add($"{weapon.type_Weapon}: {weapon.Name}, lvl {weapon.Lvl}, dm {weapon.damage}");
                        Combo_Second.Items.Add($"{weapon.type_Weapon}: {weapon.Name}, lvl {weapon.Lvl}, dm {weapon.damage}");
                        Personage_Weapon.Items.Add($"{weapon.type_Weapon}: {weapon.Name}, lvl {weapon.Lvl}, dm {weapon.damage}");
                    }
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show($"{ex.Message}");
            }
        }

        private void NewCharacter_Click(object sender, RoutedEventArgs e)
        {
            Personage personage = new Personage();  
            try
            {
                if(Personage_Name.Text != string.Empty)
                {
                    personage.Name = Personage_Name.Text;
                }
                else
                {
                    MessageBox.Show("Имя заменено по умолчанию!");
                }
                if (Personage_Lvl.Text != string.Empty && int.TryParse(Personage_Lvl.Text, out int Lvl))
                {
                    personage.Lvl = Lvl;
                }
                else
                {
                    MessageBox.Show("Уровень заменен по умолчанию!");
                }
                if (Personage_Speed.Text != string.Empty && int.TryParse(Personage_Speed.Text, out int Speed))
                {
                    personage.Speed = Speed;
                }
                else
                {
                    MessageBox.Show("Скорость заменена по умолчанию!");
                }
                if (Personage_Peri.Text != string.Empty && int.TryParse(Personage_Peri.Text, out int dexterity))
                {
                    personage.dexterity = dexterity;
                }
                else
                {
                    MessageBox.Show("Ловкость заменена по умолчанию!");
                }
                if (Personage_Intelect.Text != string.Empty && int.TryParse(Personage_Intelect.Text, out int intellect))
                {
                    personage.intellect = intellect;
                }
                else
                {
                    MessageBox.Show("Ловкость заменена по умолчанию!");
                }
                if (Personage_Weapon.SelectedIndex != -1 && Weapons[Personage_Weapon.SelectedIndex] != null)
                {
                    personage.Weapon = Weapons[Personage_Weapon.SelectedIndex];
                }
                else
                {
                    MessageBox.Show("Ваш персонаж безоружен!");
                }
                Personage_Name.Text = personage.Name;
                Personage_Lvl.Text = Convert.ToString(personage.Lvl);
                Personage_Speed.Text = Convert.ToString(personage.Speed);
                Personage_Peri.Text = Convert.ToString(personage.dexterity);
                Personage_Intelect.Text = Convert.ToString(personage.intellect);

                if (personage.Weapon != null)
                {
                    Characters.Add(personage);
                    int PowerOfPersonage = personage.GetPower(personage.Lvl, personage.Speed, personage.dexterity, personage.intellect, personage.Weapon);
                    Power_Text.Content = $"Мощность: {PowerOfPersonage}";
                    Title_Text.Content = personage.Title(PowerOfPersonage, personage.Weapon.type_Weapon);
                }
                else
                {
                    MessageBox.Show("Создайте персонажу оружие!");
                }
            }
            catch(ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "png (*.png)|*.png|All files (*.*)|*.*";
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;

            if (openFileDialog.ShowDialog() == true)
            {
                characterimage.Source = new BitmapImage(new Uri(openFileDialog.FileName));

                string imageName = openFileDialog.SafeFileName;
            }
            //imageButton.Visibility = Visibility.Hidden;
            //imageButton.IsEnabled = false;
        }
    }
}
