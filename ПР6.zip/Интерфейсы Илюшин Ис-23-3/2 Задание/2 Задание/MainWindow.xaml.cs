﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _2_Задание
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Student[] students = new Student[5];
            students[0] = new Student("Галя", 19, 4.76);
            students[1] = new Student("Женя", 20, 4.5);
            students[2] = new Student("Катя", 18, 4.2);
            students[3] = new Student("Маша", 22, 4.3);
            students[4] = new Student("Илья", 24, 4.9);
            Studs.Items.Clear();
            Array.Sort(students);
            Studs.Items.Add("По GPA");
            foreach (Student student in students)
            {
                Studs.Items.Add($"Имя: {student.Name}, Возраст: {student.Age}, GPA: {student.gPA}");
            }
            Array.Sort(students, new StudentAgeCompater());
            Studs.Items.Add("По возрасту");
            foreach (Student student in students)
            {
                Studs.Items.Add($"Имя: {student.Name}, Возраст: {student.Age}, GPA: {student.gPA}");
            }
        }
    }
}