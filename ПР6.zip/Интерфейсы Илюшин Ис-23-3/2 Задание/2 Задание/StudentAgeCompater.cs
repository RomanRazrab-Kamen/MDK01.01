﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_Задание
{
    internal class StudentAgeCompater : IComparer<Student>
    {
        public int Compare(Student x, Student y)
        {
            if (x.Age > y.Age)
            {
                return 1;
            }
            if (x.Age < y.Age)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }
    }
}
