﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_Задание
{
    internal class Student : IComparable<Student>
    {
        private string name;
        private double age;
        public string Name
        {
            get
            {
                return name;
            }
        }
        public double Age
        {
            get 
            {
                return age; 
            }
        }
        private double GPA;
        public double gPA
        {
            get
            {
                return GPA;
            }
        }

        public Student(string name, double age, double GPA)
        {
            this.name = name;
            this.age = age;
            this.GPA = GPA;
        }
        public int CompareTo(Student First)
        {
            return GPA.CompareTo(First.GPA);
        }
        public override string ToString() 
        { 
            return name;
        }
        public double GetAge()
        {
            return age;
        }
    }
}
