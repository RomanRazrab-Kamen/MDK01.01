﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    public class Dog : IAnimal
    {
        private string name;

        public Dog(string name)
        {
            this.name = name;
        }
        public string MakeSound()
        {
            return "Гав-гав!";
        }
        public string GetHabits()
        {
            return "Собаки любят кушать!";
        }
    }
}
