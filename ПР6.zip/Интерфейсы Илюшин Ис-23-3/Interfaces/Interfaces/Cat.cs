﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    public class Cat : IAnimal
    {
        private string name;
        public Cat(string name) 
        { 
            this.name = name;
        } 

        public string MakeSound()
        {
            return "Мяу";
        }
        public string GetHabits()
        {
            return "Кошики и коты спят полезное занятие!";
        }
    }
}
